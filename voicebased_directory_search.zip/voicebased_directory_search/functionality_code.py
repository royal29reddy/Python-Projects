import speech_recognition as sr
import webbrowser as wb


#initialise recognizer
r=sr.Recognizer()

def access_drives_in_pc():
    import os
    print("accessing your pc")
    os.startfile(r"Desktop\\")
    with sr.Microphone() as source:
        print("tell the drive u want to open")
        audio=r.listen(source)
        text=r.recognize_google(audio)
        if text=='open D drive':
            os.startfile(r"D:\\")
        elif text=='open C drive':
            os.startfile(r"C:\\")
        else:
            print("access is denined for other drives")

with sr.Microphone() as source:
    print("listening")
    try:
        audio=r.listen(source,phrase_time_limit=4)
        text=r.recognize_google(audio)
        if text=='access  drives':
            access_drives_in_pc()
        else:
            raise sr.UnknownValueError

    except:
        print("some prob")    
