import speech_recognition as sr
import webbrowser as wb


#initialise recognizer
r=sr.Recognizer()

def access_drives_in_pc(text):
    import os
    #print("accessing your pc")
    #os.startfile(r"Desktop\\")
    #with sr.Microphone() as source:
        #print("tell the drive u want to open")
        #audio=r.listen(source)
        #text=r.recognize_google(audio)
    if text=='open D drive':
        os.startfile(r"D:\\")
    elif text=='open C drive':
        os.startfile(r"C:\\")
    elif text=='open E drive':
        os.startfile(r"E:\\")    
    elif text=='Open F drive':
        os.startfile(r"F:\\")     
    else:
        print("access is denined for other drives")

with sr.Microphone() as source:
    print("listening")
    audio=r.listen(source,phrase_time_limit=4)
    text=r.recognize_google(audio)
    print(text)
    if text=="open D drive":
        access_drives_in_pc(text)
    elif text=="open C drive" :
        access_drives_in_pc(text)   
    elif text=="open E drive" :
        access_drives_in_pc(text)  
    elif text=="Open F drive" :
        access_drives_in_pc(text)     
    else:
        print("choose some drive")     


       
